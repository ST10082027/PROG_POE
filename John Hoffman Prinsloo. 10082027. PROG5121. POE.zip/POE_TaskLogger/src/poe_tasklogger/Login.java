/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_tasklogger;

import javax.swing.JOptionPane;

/**
 *
 * @author johnhoffmanprinsloo
 */
/*=====================================================================================================================
*     Login Class
*=====================================================================================================================
     * The Login class represents a user account for the Task Logger application.
     * It stores the user's username, password, first name, and last name.
     * It provides methods for checking the username and password complexity,
     * registering a user, logging in a user, and returning the login status.
 */
class Login {

    private String username;
    private String password;
    private String firstName;
    private String lastName;

    public Login(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /*This method checks if the username meets the required format. It verifies that the username's length is no more than
    5 characters and contains an underscore. If the username is valid, it returns true; otherwise, it returns false.*/
    public boolean checkUserName() {
        return username.length() <= 5 && username.contains("_");
    }

    /* This method validates the complexity of the password. It ensures that the password is at least 8 characters long, 
    contains an uppercase letter, a digit, and a special character. If the password meets these criteria, it returns 
    true; otherwise, it returns false.*/
    public boolean checkPasswordComplexity() {
        return password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") && password.matches(".*[^a-zA-Z0-9].*");
    }

    /*This method handles the registration process. It validates the username and password using the checkUserName() and 
    checkPasswordComplexity() methods. If the username or password is invalid, it displays an error message. Otherwise, 
    it displays a success message and returns "Registration successful."*/
    public String registerUser() {
        if (!checkUserName()) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Please ensure that your "
                    + "username contains an underscore and is no more than 5 characters in length.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return "Registration failed.";
        } else if (!checkPasswordComplexity()) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the "
                    + "password contains at least 8 characters, a capital letter, a number, and a special character.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return "Registration failed.";
        } else {
            JOptionPane.showMessageDialog(null, "Registration successful.", "Success", JOptionPane.INFORMATION_MESSAGE);
            return "Registration successful.";
        }
    }

    /*This method verifies the provided username and password against the stored username and password. If they match, it
    returns true, indicating successful login; otherwise, it returns false.*/
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    /*This method generates a login status message based on the login status (isLoggedIn). If the user is logged in, it 
    returns a welcome message with the user's first and last name. Otherwise, it returns an incorrect login message.*/
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
