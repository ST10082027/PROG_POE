/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_tasklogger;

import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author johnhoffmanprinsloo
 */
/*=====================================================================================================================
    *RunApplication Class
*=====================================================================================================================
     * The RunApplication class handles the main functionality of the Task Logger application.
     * It allows users to register, login, and perform tasks related to task management.
     * The class provides methods for registering a user, logging in, handling the task menu,
     * and adding tasks.
 */
class RunApplication {

    private Login registeredUser;
    private int totalDuration = 0;
    private String[] developers;
    private String[] taskNames;
    private String[] taskIDs;
    private int[] taskDurations;
    private String[] taskStatuses;
    private int taskCount;

    /**
     * Handles the registration and login process using JOptionPane dialog.
     * Prompts the user to choose between login, create an account, or quit.
     * Depending on the user's choice, it calls the login(), register(), or
     * terminates the program.
     */
    public void registerAndLogin() {

        String input = JOptionPane.showInputDialog(null, "Select an option:\n1. Login\n2. Create an account\n3. Quit\n\nEnter your choice:");
        if (input == null) {
            return; // User canceled, go back to main menu
        }

        switch (input) {
            case "1":
                login();
                break;
            case "2":
                register();
                break;
            case "3":
                JOptionPane.showMessageDialog(null, "Goodbye!");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid input. Goodbye!");
                break;
        }
    }

    /**
     * Collects user input for registration (username, password, first name,
     * last name) and creates an instance of the Login class with the provided
     * information. Calls the registerUser() method of the Login class to
     * register the user and displays the registration message in a dialog. If
     * the registration is successful, it calls the login() method to prompt the
     * user to log in.
     */
    public void register() {
        String username = JOptionPane.showInputDialog(null, "Enter a username:\n Please ensure that your "
                + "username contains an underscore and is no more than 5 characters in length.\n\n");
        String password = JOptionPane.showInputDialog(null, "Enter a password:\nPlease ensure that the "
                + "password contains at least 8 characters, a capital letter, a number, and a special character.\n\n");
        String firstName = JOptionPane.showInputDialog(null, "Enter your first name:");
        String lastName = JOptionPane.showInputDialog(null, "Enter your last name:");

        registeredUser = new Login(username, password, firstName, lastName);

        String registrationMessage = registeredUser.registerUser();

        if (registrationMessage.equals("Registration successful.")) {
            initializeTaskArrays();
            login();
        }
    }

    /**
     * Handles the login process using JOptionPane dialog. Prompts the user to
     * enter their username and password, validates the input by calling the
     * loginUser() method of the Login class, and displays the login status
     * message returned by the returnLoginStatus() method of the Login class. If
     * the login is successful, it calls the handleTaskMenu() method to start
     * the task management menu.
     */
    public void login() {
        if (registeredUser == null) {
            JOptionPane.showMessageDialog(null, "No registered user found. Please register first.");
            return;
        }

        String inputUsername = JOptionPane.showInputDialog(null, "Enter your username:");
        String inputPassword = JOptionPane.showInputDialog(null, "Enter your password:");

        boolean isLoggedIn = registeredUser.loginUser(inputUsername, inputPassword);

        JOptionPane.showMessageDialog(null, registeredUser.returnLoginStatus(isLoggedIn));

        if (isLoggedIn) {
            handleTaskMenu();
        }
    }

    /**
     * Displays a menu for task management using JOptionPane dialogs. Allows the
     * user to add tasks, show a report, or quit the application. Uses a loop to
     * continuously display the menu until the user chooses to quit. Calls the
     * addTask() method to add tasks and keeps track of the total task count and
     * duration.
     */
    public void handleTaskMenu() {
        boolean quit = false;
        int taskCount = 0;

        while (!quit) {
            String[] options = {"Add tasks", "Show report", "Quit"};
            int menuChoice = JOptionPane.showOptionDialog(null, "Select an option:", "Task Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            switch (menuChoice) {
                case 0:
                    String numTasksInput = JOptionPane.showInputDialog(null, "Enter the number of tasks to enter:");
                    int numTasks = Integer.parseInt(numTasksInput);

                    for (int i = 0; i < numTasks; i++) {
                        addTask();
                        taskCount++;
                    }
                    break;
                case 1:
                    showReport();
                    break;
                case 2:
                    quit = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
                    break;
            }
        }

        JOptionPane.showMessageDialog(null, "Total task count: " + taskCount + "\nTotal duration: " + totalDuration);
    }

    /**
     * Collects user input for creating a new task using JOptionPane dialogs.
     * Prompts the user to enter the task status, developer's first and last
     * name, task name, task description, and duration. Creates an instance of
     * the Task class with the provided information and calls the
     * printTaskDetails() method of the Task class to display the task details.
     * Updates the total task duration.
     */
    public void addTask() {
        String[] statusOptions = {"ToDo", "Done", "Doing"};
        String taskStatus = (String) JOptionPane.showInputDialog(null, "Select task status:",
                "Add Task", JOptionPane.PLAIN_MESSAGE, null, statusOptions, statusOptions[0]);

        String devFirstName = JOptionPane.showInputDialog(null, "Enter developer's first name:");
        String devLastName = JOptionPane.showInputDialog(null, "Enter developer's last name:");
        String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
        String description = JOptionPane.showInputDialog(null, "Enter task description (up to 50 characters):");
        int duration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration (in hours):"));

        Task newTask = new Task(taskStatus, devFirstName, devLastName, taskName, description, duration);
        newTask.printTaskDetails();
        developers[taskCount] = devLastName; // Store developer name
        taskNames[taskCount] = taskName; // Store task name
        taskIDs[taskCount] = newTask.createTaskID(); // Generate and store task ID
        taskDurations[taskCount] = duration; // Store task duration
        taskStatuses[taskCount] = taskStatus; // Store task status

        taskCount++;
        totalDuration += duration;
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
/*This method displays a menu for task reporting. It allows the user to choose different reporting options such as showing 
    tasks with status 'Done,' tasks with the longest duration, searching for tasks by name or developer, deleting a task, 
    showing full task details, or going back to the main menu.*/
    public void showReport() {
        String[] options = {"Show tasks with status 'Done'", "Show task with longest duration",
            "Search for a task by name", "Search for tasks by developer", "Delete a task", "Show full task details", "Back to main menu"};

        while (true) {
            int choice = JOptionPane.showOptionDialog(null, "Select an option:", "Task Report",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    showTasksWithStatusDone();
                    break;
                case 1:
                    showTaskWithLongestDuration();
                    break;
                case 2:
                    searchTaskByName();
                    break;
                case 3:
                    searchTasksByDeveloper();
                    break;
                case 4:
                    deleteTask();
                    break;
                case 5:
                    showFullTaskDetails();
                    break;
                case 6:
                    return; // Go back to the main menu
                default:
                    JOptionPane.showMessageDialog(null, "Invalid input. Please try again.");
                    break;
            }
        }
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    /**
     * Displays the tasks with the status 'Done' along with the developer and
     * duration.
     */
    private void showTasksWithStatusDone() {
        ArrayList<String> tasksWithStatusDone = new ArrayList<>();

        // Iterate over the tasks and check for status 'Done'
        for (int i = 0; i < taskStatuses.length; i++) {
            if (taskStatuses[i].equalsIgnoreCase("Done")) {
                String taskDetails = "Task Name: " + taskNames[i] + "\n"
                        + "Developer: " + developers[i] + "\n"
                        + "Duration: " + taskDurations[i] + " hours\n";
                tasksWithStatusDone.add(taskDetails);
            }
        }

        if (tasksWithStatusDone.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tasks with status 'Done' found.");
        } else {
            StringBuilder report = new StringBuilder("Tasks with status 'Done':\n\n");
            for (String task : tasksWithStatusDone) {
                report.append(task).append("\n");
            }
            JOptionPane.showMessageDialog(null, report.toString());
        }
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    /**
     * Displays the developer and duration of the task with the longest
     * duration.
     */
    private void showTaskWithLongestDuration() {
        int longestDuration = 0;
        String longestTaskDeveloper = "";

        // Iterate over the tasks to find the longest duration
        for (int i = 0; i < taskDurations.length; i++) {
            if (taskDurations[i] > longestDuration) {
                longestDuration = taskDurations[i];
                longestTaskDeveloper = developers[i];
            }
        }

        if (longestDuration == 0) {
            JOptionPane.showMessageDialog(null, "No tasks found.");
        } else {
            String report = "Task with longest duration:\n\n"
                    + "Developer: " + longestTaskDeveloper + "\n"
                    + "Duration: " + longestDuration + " hours\n";
            JOptionPane.showMessageDialog(null, report);
        }
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    /**
     * Searches for a task by name and displays its name, developer, and status.
     * It prompts the user for a task name, iterates over the tasks to find a
     * matching name, and generates a report with the task details if found.
     */
    private void searchTaskByName() {
        String taskNameToSearch = JOptionPane.showInputDialog(null, "Enter the task name to search:");

        boolean taskFound = false;
        StringBuilder report = new StringBuilder("Task Search Result:\n\n");

        // Iterate over the tasks to find a matching name
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(taskNameToSearch)) {
                String taskDetails = "Task Name: " + taskNames[i] + "\n"
                        + "Developer: " + developers[i] + "\n"
                        + "Status: " + taskStatuses[i] + "\n";
                report.append(taskDetails);
                taskFound = true;
            }
        }

        if (!taskFound) {
            JOptionPane.showMessageDialog(null, "No tasks with the given name found.");
        } else {
            JOptionPane.showMessageDialog(null, report.toString());
        }
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    /**
     * Searches for tasks assigned to a developer and displays their names and
     * statuses. It prompts the user for a developer name, iterates over the
     * tasks to find matching developers, and generates a report with the task
     * details if found.
     */
    private void searchTasksByDeveloper() {
        String developerToSearch = JOptionPane.showInputDialog(null, "Enter the developer name to search:");

        boolean tasksFound = false;
        StringBuilder report = new StringBuilder("Tasks assigned to " + developerToSearch + ":\n\n");

        // Iterate over the tasks to find matching developer names
        for (int i = 0; i < developers.length; i++) {
            if (developers[i] != null && developers[i].equalsIgnoreCase(developerToSearch.trim())) {
                String taskDetails = "Task Name: " + taskNames[i] + "\n"
                        + "Status: " + taskStatuses[i] + "\n";
                report.append(taskDetails);
                tasksFound = true;
            }
        }

        if (!tasksFound) {
            JOptionPane.showMessageDialog(null, "No tasks assigned to the given developer found.");
        } else {
            JOptionPane.showMessageDialog(null, report.toString());
        }
    }

    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    /**
     * Deletes a task based on its name.It prompts the user for a task name,
     * iterates over the tasks to find a matching name, and deletes the task by
     * setting its related variables to null.
     */
    private void deleteTask() {
        String taskNameToDelete = JOptionPane.showInputDialog(null, "Enter the task name to delete:");

        boolean taskDeleted = false;

        // Iterate over the tasks to find a matching name and delete it
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(taskNameToDelete)) {
                taskNames[i] = null;
                developers[i] = null;
                taskStatuses[i] = null;
                taskDurations[i] = 0;
                taskDeleted = true;
            }
        }

        if (taskDeleted) {
            JOptionPane.showMessageDialog(null, "Task deleted successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "No tasks with the given name found.");
        }
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    /**
     * Displays a report with the full details of all captured tasks. It
     * iterates over the tasks, appends their details to the report, and
     * displays it.
     */
    private void showFullTaskDetails() {
        StringBuilder report = new StringBuilder("Full Task Details:\n\n");

        // Iterate over the tasks and append their details to the report
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i] != null && !taskNames[i].isEmpty()) {
                String taskDetails = "Task Name: " + taskNames[i] + "\n"
                        + "Developer: " + developers[i] + "\n"
                        + "Status: " + taskStatuses[i] + "\n"
                        + "Duration: " + taskDurations[i] + " hours\n";
                report.append(taskDetails).append("\n");
            }
        }

        if (report.length() == 0) {
            JOptionPane.showMessageDialog(null, "No tasks found.");
        } else {
            JOptionPane.showMessageDialog(null, report.toString());
        }
    }
    //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
/*This method initializes the task-related arrays. It sets the size of the arrays, initializes all array elements with 
    empty values, and ensures they are ready to store task information.*/
    private void initializeTaskArrays() {
        int maxTasks = 100; // Maximum number of tasks

        developers = new String[maxTasks];
        taskNames = new String[maxTasks];
        taskIDs = new String[maxTasks];
        taskDurations = new int[maxTasks];
        taskStatuses = new String[maxTasks];

        // Initialize all arrays with null values
        for (int i = 0; i < maxTasks; i++) {
            developers[i] = "";
            taskNames[i] = "";
            taskIDs[i] = "";
            taskDurations[i] = 0;
            taskStatuses[i] = "";
        }
    }
}
//=====================================================================================================================
